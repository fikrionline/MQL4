<?php

/*
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);
*/

//Includes
require_once('./../includes/functions.php');
require_once('./../includes/phpQuery-onefile.php');

//CURL and Get Data
$api_url = 'http://www.massyart.com/ringsignal/api/forex'; //print_rr($api_url); exit();
$api_curl = curl_feed($api_url); //print_rr($api_curl); exit();
$doc = phpQuery::newDocument($api_curl); //print_rr($doc); exit();

//Get table
$data = array();

$data_counter = 0;
foreach (pq('div.single_wrapper') as $single_wrapper) { //print_rr($single_wrapper);
	
	$signal_per_pair = new stdClass();

	//single_wrapper
	$pull_left = pq($single_wrapper)->find('.pull-left')->text();
	$pull_left_explode = explode(' ', $pull_left);
	$pull_left = strtolower($pull_left_explode[1]); //print_rr($pull_left);

	$pull_center = pq($single_wrapper)->find('.pull-center')->text(); //print_rr($pull_center);

	$pull_right = strtolower(pq($single_wrapper)->find('.pull-right')->text()); //print_rr($pull_right);

	//single_signal
	$signal_detail = pq($single_wrapper)->find('.signal_detail')->text();
	$signal_detail_explode = explode('  ', $signal_detail);

	if($pull_right == 'active') { //print_rr($signal_detail_explode);

		$signal_per_pair->signal = $pull_left;
		$signal_per_pair->pair = $pull_center;
		$signal_per_pair->status = $pull_right;

		foreach ($signal_detail_explode as $detail) {

			if(strpos($detail, 'Open Price') !== false) {
				$signal_per_pair->OpenPrice = trim(str_replace('Open Price', ' ', $detail));
			}

			if(strpos($detail, 'Take Profit') !== false) {
				$signal_per_pair->TakeProfit = trim(str_replace('Take Profit', ' ', $detail));
			}

			if(strpos($detail, 'Stop Loss') !== false) {
				$signal_per_pair->StopLoss = trim(str_replace('Stop Loss', ' ', $detail));
			}

			if(strpos($detail, 'Open Time') !== false) {
				$detail = explode('ago', $detail);
				$detail = $detail[1];
				$detail = trim(str_replace('(UTC)', '', $detail));
				$detail = explode(' ', $detail);
				$signal_per_pair->OpenDate = trim($detail[0]);
				$signal_per_pair->OpenTime = trim($detail[1]);
			}

		}

		$data[] = $signal_per_pair;

	}

}

if(count($data) >= 1) {
	$data_json_encode = json_encode($data); echo($data_json_encode);
}
