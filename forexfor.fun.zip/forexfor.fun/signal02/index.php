<?php

/*
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);
*/

//Includes
require_once('./../includes/functions.php');
require_once('./../includes/phpQuery-onefile.php');

//CURL and Get Data
$api_url = 'http://www.massyart.com/ringsignal/'; //print_rr($api_url); exit();
$api_curl = curl_feed($api_url); //print_rr($api_curl); exit();
$doc = phpQuery::newDocument($api_curl); //print_rr($doc); exit();

//Get table
$data = array();

foreach (pq('tr.active_signal') as $active_signal) { //print_rr($active_signal);
	
	$signal_per_pair = new stdClass();

	//active_signal
	$symbol = pq($active_signal)->find('div.symbol')->text(); //print_rr($symbol);
	$signal = pq($active_signal)->find('div.type')->text(); //print_rr($type);
	$open_price_t = pq($active_signal)->find('span.open_price_t')->text(); //print_rr($open_price_t);
	$tp1_t = pq($active_signal)->find('span.tp1_t')->text(); //print_rr($tp1_t);
	$sl_t = pq($active_signal)->find('span.sl_t')->text(); //print_rr($sl_t);
	$status = pq($active_signal)->find('div.status')->text(); //print_rr($sl_t);

	$signal_per_pair->pair = $symbol;
	$signal_per_pair->signal = strtolower($signal);
	$signal_per_pair->OpenPrice = $open_price_t;
	$signal_per_pair->TakeProfit = $tp1_t;
	$signal_per_pair->StopLoss = $sl_t;
	$signal_per_pair->status = strtolower($status);

	$data[] = $signal_per_pair;

}

if(count($data) >= 1) {
	$data_json_encode = json_encode($data); echo($data_json_encode);
}
