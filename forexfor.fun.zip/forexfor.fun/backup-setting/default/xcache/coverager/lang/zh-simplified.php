<?php
// auto generated, do not modify
$strings += array(
		"Directory"
		=> "目录",
		"Percent"
		=> "覆盖率",
		"Hits"
		=> "命中",
		"Lines"
		=> "行数",
		"TODO"
		=> "闲置文件",
		"File"
		=> "文件",
		"root"
		=> "开始",
		);

