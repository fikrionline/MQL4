<?php

/*
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);
*/

//Includes
require_once('./../includes/functions.php');
require_once('./vendor/autoload.php');

$dir_name = "./temp";
$file_name = "twitter-SignalFactory-" . date("Y-m-d-H-i") . ".txt";
$full_path = $dir_name."/".$file_name; //print_rr($full_path);

if(!is_dir($dir_name)) {
	@mkdir($dir_name, 0755, TRUE);
}

$consumerKey = "fqkxDHC6YJwb7pSK1yW8TAdz5";
$consumerSecret = "fu3d7RLDhb9FL0rFtAZE4FZcpUTYOa1aRDOrQ3rky0p8ovS42n";
$accessToken = "1378553574414712835-bKQrJYULTQO2TkxMIeRvi6Tt9g2rSf";
$accessTokenSecret = "rOCHicVrxEommssDhGuYRqN0a4H3XBLJMS4vI5Otr4ScY";

use DG\Twitter\Twitter;

if(file_exists($full_path)) {
	$statuses = unserialize(file_get_contents($full_path));
} else {

	$twitter = new Twitter($consumerKey, $consumerSecret, $accessToken, $accessTokenSecret);

	$statuses = $twitter->load(Twitter::ME_AND_FRIENDS); //print_rr($statuses); exit();

	file_put_contents($full_path, serialize($statuses));

}

$data = array();

$close = array();
$close_counter = 0;

foreach ($statuses as $status) {

	if(strtolower(trim($status->user->name)) == "signal factory") {

		$status_created_at = strtotime($status->created_at);
		$different = time() - $status_created_at;
		if($different < 86400) {

			$dupllicate_checker = FALSE;

			$status_explode = explode("|", Twitter::clickable($status)); //print_rr($status_explode);

			if(isset($status_explode[1])) {
				if(substr(strtolower(trim($status_explode[1])), 0, 5) == "close") {

					$signal_type_explode = explode(" ", trim($status_explode[1])); //print_rr($signal_type_explode);
					$signal_pair_explode = explode("@", trim($signal_type_explode[2])); //print_rr($signal_pair_explode);
					$close[$close_counter]["pair"] = $signal_pair_explode[0];
					$close[$close_counter]["StopLoss"] = $signal_pair_explode[1];
					$close[$close_counter]["status"] = "closed";
					$close_counter++;

				}
			}

			if(strtolower(trim($status_explode[0])) == "forex signal" && substr(strtolower(trim($status_explode[1])), 0, 5) != "close") {

				$signal_per_pair = new stdClass();

				$signal_type_explode = explode(" ", trim($status_explode[1])); //print_rr($signal_type_explode);
				$signal_pair_explode = explode("@", trim($signal_type_explode[1])); //print_rr($signal_pair_explode);

				$signal_per_pair->pair = trim($signal_pair_explode[0]);
				$signal_per_pair->signal = trim(strtolower($signal_type_explode[0]));
				$signal_per_pair->OpenPrice = trim($signal_pair_explode[1]);
				$signal_per_pair->TakeProfit = str_ireplace("TP:", "", trim($status_explode[3]));
				$signal_per_pair->StopLoss = str_ireplace("SL:", "", trim($status_explode[2]));
				$signal_per_pair->status = "active";

				$close_checker = 0;
				if(count($close) > 0) {
					foreach ($close as $closed) {
						if(($closed["pair"] == $signal_per_pair->pair) && ($closed["StopLoss"] == $signal_per_pair->StopLoss)) {
							$close_checker = 1;
						}
					}
				}

				foreach ($data as $data_duplicate_checker) {
					if($data_duplicate_checker->pair == $signal_per_pair->pair) {
						$dupllicate_checker = TRUE;
					}
				}

				if($close_checker == 0 && $dupllicate_checker == FALSE) {
					$data[] = $signal_per_pair; //print_rr($signal_per_pair);
				}

			}

		}

	}

}

/*if($close > 0) {
	$close_json_encode = json_encode($close); echo($close_json_encode);
}*/

if(count($data) >= 1) {
	$data_json_encode = json_encode($data); echo($data_json_encode);
}
